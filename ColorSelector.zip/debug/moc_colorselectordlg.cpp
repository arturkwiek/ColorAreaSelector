/****************************************************************************
** Meta object code from reading C++ file 'colorselectordlg.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../evaa-color-selector/colorselectordlg.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'colorselectordlg.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ColorSelectorDlg_t {
    uint offsetsAndSizes[42];
    char stringdata0[17];
    char stringdata1[26];
    char stringdata2[1];
    char stringdata3[6];
    char stringdata4[26];
    char stringdata5[26];
    char stringdata6[26];
    char stringdata7[26];
    char stringdata8[26];
    char stringdata9[20];
    char stringdata10[18];
    char stringdata11[19];
    char stringdata12[20];
    char stringdata13[20];
    char stringdata14[21];
    char stringdata15[21];
    char stringdata16[21];
    char stringdata17[19];
    char stringdata18[30];
    char stringdata19[29];
    char stringdata20[7];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_ColorSelectorDlg_t::offsetsAndSizes) + ofs), len 
static const qt_meta_stringdata_ColorSelectorDlg_t qt_meta_stringdata_ColorSelectorDlg = {
    {
        QT_MOC_LITERAL(0, 16),  // "ColorSelectorDlg"
        QT_MOC_LITERAL(17, 25),  // "on_hsHSVHMin_valueChanged"
        QT_MOC_LITERAL(43, 0),  // ""
        QT_MOC_LITERAL(44, 5),  // "value"
        QT_MOC_LITERAL(50, 25),  // "on_hsHSVSMin_valueChanged"
        QT_MOC_LITERAL(76, 25),  // "on_hsHSVVMin_valueChanged"
        QT_MOC_LITERAL(102, 25),  // "on_hsHSVHMax_valueChanged"
        QT_MOC_LITERAL(128, 25),  // "on_hsHSVSMax_valueChanged"
        QT_MOC_LITERAL(154, 25),  // "on_hsHSVVMax_valueChanged"
        QT_MOC_LITERAL(180, 19),  // "on_btnGreen_clicked"
        QT_MOC_LITERAL(200, 17),  // "on_btnRed_clicked"
        QT_MOC_LITERAL(218, 18),  // "on_btnBlue_clicked"
        QT_MOC_LITERAL(237, 19),  // "on_btnBlack_clicked"
        QT_MOC_LITERAL(257, 19),  // "on_btnWhite_clicked"
        QT_MOC_LITERAL(277, 20),  // "on_btnYellow_clicked"
        QT_MOC_LITERAL(298, 20),  // "on_btnPurple_clicked"
        QT_MOC_LITERAL(319, 20),  // "on_btnOrange_clicked"
        QT_MOC_LITERAL(340, 18),  // "on_btnGray_clicked"
        QT_MOC_LITERAL(359, 29),  // "on_ColorSelectorDlg_destroyed"
        QT_MOC_LITERAL(389, 28),  // "on_ColorSelectorDlg_finished"
        QT_MOC_LITERAL(418, 6)   // "result"
    },
    "ColorSelectorDlg",
    "on_hsHSVHMin_valueChanged",
    "",
    "value",
    "on_hsHSVSMin_valueChanged",
    "on_hsHSVVMin_valueChanged",
    "on_hsHSVHMax_valueChanged",
    "on_hsHSVSMax_valueChanged",
    "on_hsHSVVMax_valueChanged",
    "on_btnGreen_clicked",
    "on_btnRed_clicked",
    "on_btnBlue_clicked",
    "on_btnBlack_clicked",
    "on_btnWhite_clicked",
    "on_btnYellow_clicked",
    "on_btnPurple_clicked",
    "on_btnOrange_clicked",
    "on_btnGray_clicked",
    "on_ColorSelectorDlg_destroyed",
    "on_ColorSelectorDlg_finished",
    "result"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ColorSelectorDlg[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  116,    2, 0x08,    1 /* Private */,
       4,    1,  119,    2, 0x08,    3 /* Private */,
       5,    1,  122,    2, 0x08,    5 /* Private */,
       6,    1,  125,    2, 0x08,    7 /* Private */,
       7,    1,  128,    2, 0x08,    9 /* Private */,
       8,    1,  131,    2, 0x08,   11 /* Private */,
       9,    0,  134,    2, 0x08,   13 /* Private */,
      10,    0,  135,    2, 0x08,   14 /* Private */,
      11,    0,  136,    2, 0x08,   15 /* Private */,
      12,    0,  137,    2, 0x08,   16 /* Private */,
      13,    0,  138,    2, 0x08,   17 /* Private */,
      14,    0,  139,    2, 0x08,   18 /* Private */,
      15,    0,  140,    2, 0x08,   19 /* Private */,
      16,    0,  141,    2, 0x08,   20 /* Private */,
      17,    0,  142,    2, 0x08,   21 /* Private */,
      18,    0,  143,    2, 0x08,   22 /* Private */,
      19,    1,  144,    2, 0x08,   23 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   20,

       0        // eod
};

void ColorSelectorDlg::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ColorSelectorDlg *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_hsHSVHMin_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 1: _t->on_hsHSVSMin_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->on_hsHSVVMin_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 3: _t->on_hsHSVHMax_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 4: _t->on_hsHSVSMax_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 5: _t->on_hsHSVVMax_valueChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 6: _t->on_btnGreen_clicked(); break;
        case 7: _t->on_btnRed_clicked(); break;
        case 8: _t->on_btnBlue_clicked(); break;
        case 9: _t->on_btnBlack_clicked(); break;
        case 10: _t->on_btnWhite_clicked(); break;
        case 11: _t->on_btnYellow_clicked(); break;
        case 12: _t->on_btnPurple_clicked(); break;
        case 13: _t->on_btnOrange_clicked(); break;
        case 14: _t->on_btnGray_clicked(); break;
        case 15: _t->on_ColorSelectorDlg_destroyed(); break;
        case 16: _t->on_ColorSelectorDlg_finished((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject ColorSelectorDlg::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_ColorSelectorDlg.offsetsAndSizes,
    qt_meta_data_ColorSelectorDlg,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_ColorSelectorDlg_t
, QtPrivate::TypeAndForceComplete<ColorSelectorDlg, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>


>,
    nullptr
} };


const QMetaObject *ColorSelectorDlg::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ColorSelectorDlg::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ColorSelectorDlg.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int ColorSelectorDlg::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 17)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 17;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
